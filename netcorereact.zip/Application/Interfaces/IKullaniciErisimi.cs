namespace Application.Interfaces
{
    public interface IKullaniciErisimi
    {
        string GetCurrentUserName();    
    }
}