export const kategori = [
  { key: "kultur", text: "Kültür", value: "kultur" },
  { key: "muzik", text: "Müzik", value: "muzik" },
  { key: "film", text: "Film", value: "film" },
  { key: "gezi", text: "Gezi", value: "gezi" },
  { key: "bulusma", text: "Buluşma", value: "bulusma" }
];
